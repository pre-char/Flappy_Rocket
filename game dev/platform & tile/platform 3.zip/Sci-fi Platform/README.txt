Created by Joseph Crown
All sprites are attribution free and can be used for commercial and non-commercial purposes.

Attribution is not mandatory but I would be grateful if you considered adding it.
Opengameart.org/user/jcrown41